import server.MainServer;

public class Server {
	

	//Please start with this class before start client class
	
	//Server port
	private static int port = 8803;
	
	public static int numPassengers;
	public static int numCars;
	public static int numControllers;
	public static int numSeats;
	
	public static void main(String[] args) {
		
		numPassengers = Integer.parseInt(args[0]);
		numCars = Integer.parseInt(args[1]);
		numControllers = Integer.parseInt(args[2]);
		numSeats = Integer.parseInt(args[3]);
		
		MainServer server = new MainServer(port,numPassengers,numCars,numControllers,numSeats);
		System.out.println(server.serverInfo());
		server.start();
	}

	
	

}
