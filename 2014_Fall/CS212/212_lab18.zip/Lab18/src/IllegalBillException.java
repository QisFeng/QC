
public class IllegalBillException extends IllegalArgumentException{
	public IllegalBillException(String message){
		super(message);
	}
}
