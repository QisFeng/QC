
public class Controller extends Thread {
	public Controller(int i) {
		super("Controller#" + i);
	}

	public void run() {
		while (Project1.numCarDone < Project1.numCars) {
			Project1.pc.receiveRequest(this);
			if (Project1.numCarDone == Project1.numCars){//if all car done break
				break;
			}
			booking(7);
			Project1.pc.givePermission();
		}
		msg(" exit...");
	}

	private void booking(int num) {
		try {
			sleep(Project1.rand.nextInt(Project1.MAXWAITTIME * num));
			msg("dealing with request and booking.");
		} catch (InterruptedException e) {
		}
	}// wander method

	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project1.time) + "]" + getName() + ": " + m);
	}// msg
}
