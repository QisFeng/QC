import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ThreadB extends Thread{
	private int id;
	private InputStream        is;
	private InputStream		   isOb;
 	private OutputStream       os;
 	private ObjectOutputStream oos;
 	private ObjectInputStream ois;

	public ThreadB(int id, InputStream is, InputStream isOb, OutputStream os, ObjectOutputStream oos, ObjectInputStream ois){
		this.id = id;
		this.is = is;
		this.isOb = isOb;
		this.os = os;
		this.oos = oos;
		this.ois = ois;		
	}
	
	public void run(){
		System.out.println( "Thread B starts execution...");
	    
		try {
			//receive object Message from Thread A
			ois = new ObjectInputStream ( isOb );
			Message m = (Message) ois.readObject();
			System.out.println("Thread B - receives an Object from Thread A : "+m);
			
	        //send Message to Thread C
	    	oos = new ObjectOutputStream( os );
	        oos.writeObject( m );
	        System.out.println("Thread B - sends this Object to Thread C.");
	        
	        // receive primitive data from Thread C
	        System.out.println("Thread B - receives primitive data from Thread C : "+is.read());
			
			
		} catch (Exception e) {
			System.out.println( "Error ThreadB: " + e);
		}
	}
	
	
}
