

public class ArrayStack {
	private int top;
	private int[]data;
	private int max = 10;
	
	public ArrayStack(){
		data= new int [max];
		top = -1;
	}
	public boolean isEmpty(){
		return(top==-1);
	}
	public void makeEmpty(){
		top=-1;
	}
	public int Top() throws Exception{
		if (isEmpty())
			throw new Exception("ArrayStack top");
		return data[top];
	}
	public void Pop() throws Exception{
		if (isEmpty())
			throw new Exception("ArrayStack top");
		top--;
	}
	public int TopandPop() throws Exception{
		if (isEmpty())
			throw new Exception("ArrayStack top");
		int oldtop = data[top];
		top--;
		return oldtop;
	}
	public void Push(int x){
		if (top==data.length-1){
			int newdata []= new int [2*max];
			for(int i=0;i<=top;i++)
				newdata[i]=data[i];
			data = newdata;
		}
		data[++top]=x;
	}
	
	
}
