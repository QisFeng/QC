import java.util.Random;
/**
 * @author Yuqian Zhang
 * CS344-715  Project1
 * */

public class Project1 {
	
	public static int numPassengers;//numPassengers
	public static int numCars;//numCars
	public static int numControllers;//numControllers
	public static int numSeats;//numSeats
	
	public static long time = System.currentTimeMillis();
	public static final int MAXWAITTIME = 1000;
	public static Random rand = new Random();
	
	public static boolean all_took_ride = false;
	public static int numCarDone = 0;
	static MonitorPC pc = null;

	
	
	public static void main(String[] args) {
		
		numPassengers = Integer.parseInt(args[0]);
		numCars = Integer.parseInt(args[1]);
		numControllers = Integer.parseInt(args[2]);
		numSeats = Integer.parseInt(args[3]);
		
		pc = new MonitorPC();//make monitor available
		
		 //start Passenger thread
		for(int id =1;id<=numPassengers ;id++){
			new Passenger(id).start();
		}
		 //start Car thread
		for (int id = 1; id <= numCars; id++){ 
			new Car(id).start();
		 }
		 
		 //start Controller thread
		for(int id =1; id<= numControllers;id++){
			new Controller(id).start();
		}	
	}// main method
	
}
