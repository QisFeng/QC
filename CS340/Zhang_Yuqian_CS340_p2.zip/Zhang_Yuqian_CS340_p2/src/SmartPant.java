public class SmartPant extends Thread {

	static Contestant SayingCongtowho; // The contestant SmartPants congratulate to

	public SmartPant(String title) {
		super(title);
	}

	public void run() {
		talktoCT();
		congtoCT();
	}

	private void talktoCT() {
		try {
			msg("----Waiting for Contestants----");
			SharedVariable.waitforCT.acquire();//block until all CTs arrive
			msg("All CTs arrived. GAME START!");
			for (int i = 1; i <= Project2.num_Contestant; i++) {
				SharedVariable.talkedtoSP.release(); //Talk to CT one by one
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// SmartPant congratulates contestants and ends the show if all contestants are done
	private void congtoCT() {
		while (true) {
			if (Project2.contestant_done == Project2.num_Contestant) {
				msg("*****Times up, show ends*****");
				Project2.show_ends = true;// announce that show ends
				while (!Date.available.isEmpty()) {
					Date.available.remove().endShow();//let all dates leaving
				}
				return;
			}
			try {
				SharedVariable.sayingCongto.acquire();//wait until get notified by a finished CT
				msg("Congratulations," + SayingCongtowho.getName() + "!");
				SharedVariable.congratulatedready.release();//said Congratulations 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}//show ends 
	}

	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project2.time) + "]" + getName() + " : " + m);
	}// msg

}// SmartPant
