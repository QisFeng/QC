package server;
import java.util.Vector;

public class MonitorPC {

	private int numofSeats = Project1.numSeats;//total seats on each car
	public int countPassenger = 0;//counting Passengers who took ride 
	private boolean isLoading = false;

	private Vector<Object> waitingPassenger = new Vector<Object>();
	private Vector<Car> waitingCar = new Vector<Car>();
	private Vector<Object> waitingPermission = new Vector<Object>();

	private Object oktoDrive = new Object();
	private Object oktoRequest = new Object();

	public Car getOn(Passenger passenger) {
		Object convey = new Object();
		Car currentCar = null;
		synchronized (convey) {
			// check if there is available car to get on
			if (noCarAvailabe(convey)) {
				while (true) {// wait to be notified, not interrupted
					try {
						msg(passenger.getName() + " waiting in the line.");
						convey.wait();
						waitingPassenger.remove(0);
						break;
					} catch (InterruptedException e) {
						continue;
					}
				}
			} // if statement
			synchronized (oktoDrive) {
				currentCar = waitingCar.elementAt(0);
				msg(passenger.getName() + " gets on car " + currentCar.getName());
				currentCar.useSeat();//took one seat 
				++countPassenger;//update countPassenger
				//if seats all taken, wait for next available car 
				//or for the last car that passengers are not full
				if (currentCar.getSeatUsed() == numofSeats
						|| (currentCar.getSeatUsed() > 0 && countPassenger == Project1.numPassengers)) {
					waitingCar.remove(0);
					System.out.println("===>>> current waiting car amount: " + waitingCar.size());
					oktoDrive.notifyAll();
				}

			}
			isLoading = false;//update sharing variable make sure waiting passengers can use 
			if (!waitingPassenger.isEmpty() && !waitingCar.isEmpty()) {
				//if there are waiting passengers lines up and there are available cars, helps to notify next person
				Object next = waitingPassenger.elementAt(0);
				synchronized (next) {
					msg(passenger.getName() + " notifies next passenger........");
					next.notify(); // notify next passenger
				}
			}

		}
		synchronized (currentCar) {
			try {
				currentCar.wait();//current car waits on oktoDrive lock
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return currentCar;
	}

	private synchronized boolean noCarAvailabe(Object convey) {
		boolean status;
		//System.out.println("Waiting car size: " + waitingCar.size()+"---");
		//check if loading status, waitingCar and waitingPassenger
		if (isLoading == true || waitingCar.isEmpty() || !waitingPassenger.isEmpty()) {
			waitingPassenger.addElement(convey);
			status = true;
		} else {
			isLoading = true;
			status = false;
		}
		return status;
	}

	public void getOff(Passenger passenger, Car car) {
		synchronized (car) {
			msg(passenger.getName() + " gets off the car " + car.getName());
			car.releaseSeat();
			if (car.getSeatUsed() == 0) {
				// notify car to join waitingCar
				car.notify();
			}
		}
	}

	public void load(Car car) {
		msg(car.getName()+": arrives and available to load passengers.");
		waitingCar.addElement(car);
		if (!waitingPassenger.isEmpty() && !isLoading) {
			Object next = waitingPassenger.elementAt(0);
			synchronized (next) {
				msg(car.getName() + ": notifies next passenger.....");
				next.notify();
			}
		}
		synchronized (oktoDrive) { // oktoDrive lock
			while (true) {
				try {
					if (car.getSeatUsed() == numofSeats
							|| (car.getSeatUsed() > 0 && countPassenger == Project1.numPassengers)
							|| Project1.all_took_ride) {
						break;
					}
					//System.out.println("car waiting:" + car.getName());
					oktoDrive.wait(); // while true. check seatUsed.
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
		}
	}

	public void getPermission(Car car) {
		msg(car.getName() + ": asks permission~~~");
		Object oktoPermit = new Object();
		waitingPermission.addElement(oktoPermit);
		synchronized (oktoRequest) {
			oktoRequest.notifyAll();//notify wake controllers
		}
		synchronized (oktoPermit) {
			while (true) {// wait to be notified, not interrupted
				try {
					if (waitingPermission.contains(oktoPermit)) {
						msg(car.getName() + " is waiting for permission.......");
						oktoPermit.wait();
					}
					break;
				} catch (InterruptedException e) {
					continue;
				}
			}
		}
	}

	public void unload(Car car) {
		msg( car.getName()+": is unloading......" );
		synchronized (car) {
			car.notifyAll();
			try {
				car.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (countPassenger == Project1.numPassengers) {
			// done
			Project1.all_took_ride = true;
			synchronized (oktoDrive) {
				oktoDrive.notifyAll(); // notify other cars to end
			}
			carDone();
		}
	}

	public void receiveRequest(Controller controller) {
		synchronized (oktoRequest) {
			while (true) {
				if (waitingPermission.isEmpty() && Project1.numCarDone < Project1.numCars) {
					try {
						msg(controller.getName() + ": is avaialbe and waiting for receiving request.");
						oktoRequest.wait();
						//msg(controller.getName() + ": can give permission");
						break;
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					//msg(controller.getName() + ": can give permission");
					break; // continue check next waiting permission car.
				}
			}
		}
	}

	public void givePermission() {
		if (!waitingPermission.isEmpty()) {
			Object oktoPermit = waitingPermission.remove(0);
			synchronized (oktoPermit) {
				oktoPermit.notify();
			}
		}
	}

	public synchronized void carDone() {
		Project1.numCarDone++;
		System.out.println("***" + Project1.numCarDone+" car done job and exit...***");
		if (Project1.numCarDone == Project1.numCars) {
			synchronized (oktoRequest) {
				oktoRequest.notifyAll(); // notify controllers to end
			}
		}
	}
	
	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project1.time) + "]" + m);
	}// msg

}
