import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Random;

public class test {
	static commonInterface server;
	public static int port = 0;
	public static String serverName = "";

	public static void main(String args[]) {
		serverName = args[0];
		port = Integer.parseInt(args[1]);
		try {
			String name = "server";
			Registry registry = LocateRegistry.getRegistry(serverName, port);// ("localhost",3000);
			server = (commonInterface) registry.lookup(name);

			// positive test starts here
			System.out.println("---------Positive Tests---------");

			// ---------add a new billing code---------Here for test add 5 billing code: 1-5
			for (int i = 1; i <= 5; i++) {
				boolean create;
				create = server.add_Billing_code(i);
				if (create)
					System.out.println("A new billing Code:" + i + " added successfully.");
				else
					System.out.println("A new billing Code:" + i + " failed to add.");
			}

			// ---------submit a new expense---------Here just for test add 3 expenses
			// expense record 1
			expense obj1 = new expense(server.idGenerator(), 1, 1, 555, "charged for extra time.");
			boolean ae1;
			ae1 = server.submit_Expense(obj1);
			if (ae1)
				System.out.println("Submit Expense into billingCode 1" + " successfully.");
			else
				System.out.println("Submit Expense into billingCode 1" + " failed.");
			// expense record 2
			expense obj2 = new expense(server.idGenerator(), 3, 9, 98, "charged for additional asset.");
			boolean ae2;
			ae2 = server.submit_Expense(obj2);
			if (ae2)
				System.out.println("Submit Expense into billingCode 3" + " successfully.");
			else
				System.out.println("Submit Expense into billingCode 3" + " failed.");
			// expense record 3
			expense obj3 = new expense(server.idGenerator(), 5, 23, 200, "charged for extra time.");
			boolean ae3;
			ae3 = server.submit_Expense(obj3);
			if (ae3)
				System.out.println("Submit Expense into billingCode 5" + " successfully.");
			else
				System.out.println("Submit Expense into billingCode 5" + " failed.");

			// ---------test invalidate_a_Billing_code method---------invalid billing code 1
			boolean validB;
			validB = server.invalidate_a_Billing_code(1);
			if (validB)
				System.out.println("Invalidate a billing code_1" + " successfully.");
			else
				System.out.println("Invalidate a billing code_1" + " failed.");

			// ---------get_all_Expenses_for_a_Billing_code 3--------
			System.out.println("Get all Expenses for billing code:3");
			ArrayList<expense> list = server.get_all_Expenses_for_a_Billing_code(3);
			if (list.size() == 0)
				System.out.println("No expenses for this billing code");
			else {
				for (int i = 0; i < list.size(); i++) {
					System.out.println(i + "" + list.get(i));
				}
			}

			// ---------invalidate_Expense---------invalidate expense id:1,2
			ArrayList<Integer> a = new ArrayList<Integer>();
			a.add(1);
			a.add(2);
			boolean ve;
			ve = server.invalidate_Expense(a);
			if (ve)
				System.out.println("invalication expense id:1&2 success.");
			else
				System.out.println("invalidation expense id:1&2 failed.");

			// ---------close_Account---------close account for billing code:2
			int totalnumber = server.close_Account(2);
			System.out.println("close accout for billingCode 2 " + "Total needs to pay:" + totalnumber);

			// negative test starts here
			System.out.println("---------Negative Tests---------");

			// ---------add a new billing code 2---------
			boolean nc;
			nc = server.add_Billing_code(2);
			if (nc)
				System.out.println("A new billing Code 2:" + " added successfully.");
			else
				System.out.println("A new billing Code 2:" + " failed to add.");

			// ---------invalidate a billing code 5 and use the old one to submit a expense---------
			boolean valid;
			valid = server.invalidate_a_Billing_code(5);
			if (valid)
				System.out.println("Invalidate a billing code 5" + " successfully.");
			else
				System.out.println("Invalidate a billing code 5" + " failed.");

			expense obj4 = new expense(server.idGenerator(), 5, 9, 98, "charged for extra time.");
			boolean ae4;
			ae4 = server.submit_Expense(obj4);
			if (ae4)
				System.out.println("Submit Expense into billingCode 5" + " successfully.");
			else
				System.out.println("Submit Expense into billingCode 5" + " failed.");

			// ---------invalidate expense---------invalidate expense id:1,2
			ArrayList<Integer> b = new ArrayList<Integer>();
			b.add(1);
			b.add(2);
			boolean vg;
			vg = server.invalidate_Expense(b);
			if (vg)
				System.out.println("invalication expense success.");
			else
				System.out.println("invalidation expense failed.");

			// ---------get All Expenses for billing code 1---------
			System.out.println("Get all Expenses for billing code:1");
			ArrayList<expense> l = server.get_all_Expenses_for_a_Billing_code(1);
			if (l.size() == 0)
				System.out.println("There is no expense for this billing code");
			else {
				for (int i = 0; i < l.size(); i++)
					System.out.println(i + "" + l.get(i));
			}

			// ---------simulating the audit process---------
			System.out.println("---------Simulating the audit process---------");

			// Client gets or downloads a list of All Expenses related to a
			// Billing Code 3 from the Server application.
			ArrayList<expense> exlist = server.get_all_Expenses_for_a_Billing_code(3);
			System.out.println("Get all Expenses returned for billingcode" + 3);
			if (exlist.size() == 0)
				System.out.println("There is no expense for this billing code");
			else {
				for (int i = 0; i < exlist.size(); i++) {
					System.out.println(i + "" + exlist.get(i));
				}
			}

			// randomly decide which Employee Name/ID is the offending person.
			// Then, keep track of the list of all expenses to be removed
			Random rand = new Random();
			ArrayList<Integer> rm = new ArrayList<Integer>();
			if (exlist.size() == 0) {
				System.out.println("There is no data of employeeId this the database");
				System.exit(0);
			}
			int index = rand.nextInt(exlist.size());
			int eid = exlist.get(index).employeeId;
			for (int i = 0; i < exlist.size(); i++) {
				if (exlist.get(i).employeeId == eid)
					rm.add(new Integer(exlist.get(i).id));
			}

			// Client then submits request to the Server to remove all offending
			// expenses.
			boolean isTrue = server.invalidate_Expense(rm);
			if (isTrue)
				System.out.println("invalication expense success.");
			else
				System.out.println("invalidation expense failed.");

			// Client then closes the account, pays all expenses and removes the
			// billing code
			int n = server.close_Account(3);
			System.out.println("close accout for billingCode 3 " + "Total needs to pay:" + n);

		} catch (Exception e) {
			System.err.println("Client exception:");
			e.printStackTrace();
		}

	}
}
