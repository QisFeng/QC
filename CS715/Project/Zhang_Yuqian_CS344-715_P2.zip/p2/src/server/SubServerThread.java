package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import common.Message;
import common.Message.Command;
import common.Message.Role;

public class SubServerThread implements Runnable  {
	
	private Socket socket = null;
	private Thread thread = null;//sub-server thread
	
	private static Map<String, Passenger> passengers = new HashMap<String, Passenger>();
	private static Map<String, Car> cars = new HashMap<String, Car>();
	private static Map<String, Controller> controllers = new HashMap<String, Controller>();
	

	private String name;

	public SubServerThread(Socket socket) {//Construct thread with socket
		this.socket = socket;
		this.thread = new Thread(this);
	}

	public void start() {
		this.thread.start();
	}
	
	@Override
	public void run() {
		System.out.println("starting...");
		try {
			// input/output stream
			ObjectOutputStream dos = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream dis = new ObjectInputStream(socket.getInputStream());
			
			// ask client to identify itself
			Message msg = new Message("Service", Role.Service,"What's your name?");
			System.out.println("Send identity request.");
			dos.writeObject(msg);
			System.out.println("waiting for identity...");
			msg = (Message) dis.readObject();
			
			// change thread name
			this.name = "SERVICING::" + msg.getSender();
			this.thread.setName(this.name);
			
			// read to service
			dos.writeObject(new Message(name, Role.Service, "Welcome! I am "+ name + ". How can I help you?"));
			do {
				// handle requests
				Message rcvMsg = (Message) dis.readObject();
				System.out.println("received: " + rcvMsg);
				if (Command.EXIT == rcvMsg.getCommad()) {
					socket.close();
					break;
				}
				dos.writeObject(handleMessage(rcvMsg));
			} while (true);
		} catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println(this.thread.getName()+" exit");
	}

	
	//Handle all supported messages 
	private Message handleMessage(Message msg) {
		switch (msg.getRole()) {
		case Passenger:
			msg = handlePassengerMsg(msg);
			break;

		case Car:
			msg = handleCarMsg(msg);
			break;

		case Controller:
			msg = handleControllerMsg(msg);
			break;
			
		case Other:
			msg = handleOtherMsg(msg);
			break;

		default:
			break;
		}
		return msg;
	}

	//Handle all messages from Passenger
		private Message handlePassengerMsg(Message msg) {
			System.out.println("handlePassengerMsg: " + msg);
			Message rtnMsg = new Message(this.name, Role.Service, Command.next);
			Passenger p = findOrCreatePassenger(msg.getSender());
			switch (msg.getCommad()) {
			case wander:
				p.wander(5);
				rtnMsg.setTxtMsg("wandering for a random time");
				break;
			case getOn:
				Car car = Project1.pc.getOn(p);
				rtnMsg.setTxtMsg(car.getName());
				break;
			case getOff:
				Car carr = null;
				carr = findOrCreateCar(msg.getTxtMsg());
				Project1.pc.getOff(p, carr);
				passengers.remove(msg.getSender());
				rtnMsg.setTxtMsg("gets off from car" + carr);
				break;
				
			default:
				break;
			}
			return rtnMsg;
		}
		//Handle all messages from CarClient
		private Message handleCarMsg(Message msg) {
			System.out.println("handleCartMsg: " + msg);
			Message rtnMsg = new Message(this.name, Role.Service, Command.next);
			Car c = findOrCreateCar(msg.getSender());
			switch (msg.getCommad()) {
			case load:
				Project1.pc.load(c);
				rtnMsg.setIntValue(c.getSeatUsed());
				rtnMsg.setCommand(Command.getPermission);;
				break;
				
			case getPermission:
				Project1.pc.getPermission(c);
				break;
				
			case rideAround:
				c.rideAround(4);
				break;
				
			case unload:				
				Project1.pc.countPassenger = msg.getIntValue();
				Project1.pc.unload(c);
				rtnMsg.setTxtMsg(Boolean.toString(Project1.all_took_ride));
				//rtnMsg.setCommand(Command.EXIT);
				break;
				
			case finish:
				Project1.pc.carDone();
				cars.remove(msg.getSender());
				
				break;
			default:
				break;
			}
			return rtnMsg;
		}
	
	 //Handle all messages from ControllerClient.
	private Message handleControllerMsg(Message msg) {
		System.out.println("handleControllerMsg: " + msg);
		Message rtnMsg = new Message(this.name, Role.Service,Command.next);
		Controller cl = findOrCreateController(msg.getSender());
		switch (msg.getCommad()) {
		case receiveRequest:
			Project1.pc.receiveRequest(cl);
			break;
			
		case booking:
			cl.booking(7);
			break;
			
		case givePermission:
			Project1.pc.givePermission();
			break;	
			
		case quit:
			controllers.remove(msg.getSender());
			break;
			
		default:
			break;
		}
		return rtnMsg;
	}
	
	//Handle all messages from Client -configuration.
	private Message handleOtherMsg(Message msg) {
		System.out.println("handleOtherMsg: " + msg);
		Message rtnMsg = new Message(this.name, Role.Service, Command.next);
		switch (msg.getCommad()) {
		case config_numPassengers:
			rtnMsg.setIntValue(Project1.numPassengers);
			break;
			
		case config_numCars:
			rtnMsg.setIntValue(Project1.numCars);
			break;
		
		case config_numControllers:
			rtnMsg.setIntValue(Project1.numControllers);
			break;
		case config_numSeats:
			rtnMsg.setIntValue(Project1.numSeats);
			rtnMsg.setCommand(Command.EXIT);
			
		default:
			break;
		}
		return rtnMsg;
	}
	private Passenger findOrCreatePassenger(String name) {
		Passenger p = passengers.get(name);
		if (p == null) {
			p = new Passenger(name);
			passengers.put(name, p);
		}
		return p;
	}
	
	private Car findOrCreateCar(String name) {
		Car car = cars.get(name);
		if (car == null) {
			car = new Car(name);
			cars.put(name, car);
		}
		return car;
	}

	private Controller findOrCreateController(String name) {
		Controller cl = controllers.get(name);
		if (cl == null) {
			cl = new Controller(name);
			controllers.put(name, cl);
		}
		return cl;
	}
	
	//get thread name
	public String getName() {
		return name;
	}


	
}