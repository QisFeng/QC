
 class DateNode {
	protected Date212 data;
	protected DateNode next;
	
	DateNode(Date212 d){
		data = d;
		next = null;
	}


}
