import java.util.concurrent.ConcurrentLinkedQueue;

public class SmartPant extends Thread {

   static ConcurrentLinkedQueue<Contestant> spQ = new ConcurrentLinkedQueue<>(); // contestants arrives in smartpantQ waiting to enter the club
   static int talkedNum = 0; // The number of contestants that SmartPant talked to and pass into the club
   static Contestant SayingCongto; // The contestant SmartPants congratulate to
   

   public SmartPant(String title) {
      super(title);
   }

   public void run() {
      talktoSP();
      congtoSP();
   }

   // SmartPant talk to contestants in FCFS order and pass them into the club.
   private void talktoSP() {
      msg("GAME START!");
      while (talkedNum < Project1.num_Contestant) {
         if (!spQ.isEmpty()) { // check if there is Contestant waiting in the spQ, if so, talk to him and pass him into club
            msg(spQ.peek().getName() + " now can enter the club.");//get the first elment in the spQ 
            spQ.poll().interrupt();//pop it out after called, and tell the waiting contestant about it by using interrupt
            talkedNum++;//increase # of contestants talked to
         }
      }//when spQ is empty and smartpant has talked to each contestant, jump out of while loop and move on to next action
   }

   // SmartPant congratulates contestants and ends the show if all contestants are done.
   private void congtoSP() {
      while (!Project1.show_ends) {
    	  // smartpant was blocked into a long sleep until pat by finished contestants
    	  while (!interrupted()); 
    	  msg("Congratulations, " + SayingCongto.getName());//say Congratualtions to the contestant pat him
    	// check if all contestants are done
    	  if (Project1.contestant_done == Project1.num_Contestant) { 
    		  msg("Times up, show ends.");
              Project1.show_ends = true;//announce that show ends
         }
         SayingCongto.interrupt();//returning msg back to contestant pat him 
      }//if show ends, loop ends
   }

   private void msg(String m){ 
		System.out.println("["+(System.currentTimeMillis()-Project1.time)+"]"+getName()+" : "+m);
	}//msg

}//SmartPant
