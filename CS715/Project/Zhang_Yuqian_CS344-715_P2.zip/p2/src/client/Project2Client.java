package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import common.Message;
import common.Message.Command;
import common.Message.Role;

public class Project2Client {
	private int port;	
	private String address;
	private Socket connection;
	
	public static int numPassengers;
	public static int numCars;
	public static int numControllers;
	
	//public static int countPassenger = 0;
	public static int numCarDone = 0;
	public static boolean all_took_ride = false;
	//Construct with server address and port
	
	public Project2Client(String address, int port) {
		this.address = address;
		this.port = port;
	}

	//Start client
	public void start() {
		try {
			connection = new Socket(address, port);
			System.out.println("Connect established");
			ObjectOutputStream dos = new ObjectOutputStream(connection.getOutputStream());
			ObjectInputStream dis = new ObjectInputStream(connection.getInputStream());
			
			// client identity
			Message msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			Message cfgMsg = new Message("Project2Client", Role.Other,"Project2Client");
			System.out.println("Send identity: " + cfgMsg);
			dos.writeObject(cfgMsg);
			msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			
			// configuration to get server setup information
			cfgMsg = new Message("Project2Client", Role.Other,Command.config_numPassengers);
			System.out.println("Data configuration_numPassengers: " + cfgMsg);
			dos.writeObject(cfgMsg);
			msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			numPassengers = msg.getIntValue();// # of numPassenger that server supports
			
			cfgMsg = new Message("Project2Client", Role.Other,Command.config_numCars);
			System.out.println("Data configuration_numCars: " + cfgMsg);
			dos.writeObject(cfgMsg);
			msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			numCars = msg.getIntValue();// # of numCars that server supports
			
			cfgMsg = new Message("Project2Client", Role.Other,Command.config_numControllers);
			System.out.println("Data configuration_numControllers: " + cfgMsg);
			dos.writeObject(cfgMsg);
			msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			numControllers = msg.getIntValue();// # of numControllers that server supports
			
		/*	cfgMsg = new Message("Project2Client", Role.Other,Command.config_numSeats);
			System.out.println("Data configuration_numSeats: " + cfgMsg);
			dos.writeObject(cfgMsg);
			msg = (Message) dis.readObject();
			System.out.println("The server responds: " + msg);
			int numSeats = msg.getIntValue();// # of numSeats that server supports   */
			
			System.out.println("Send exit connection command: " + cfgMsg);
			cfgMsg = new Message("Project2Client", Role.Other, Command.EXIT);
			dos.writeObject(cfgMsg);
			// close connection
			connection.close();
			
			// initialize Passengers
			for(int i = 1;i<= numPassengers;i++){
				Socket passengerSocket = new Socket(address, port);
				Thread passengerT = new Thread(new PassengerClient(passengerSocket, i));
				passengerT.start();
			}
			
			// initialize Cars
			for (int i = 1; i <= numCars; i++) {
				Socket carSocket = new Socket(address, port);
				Thread carT = new Thread(new CarClient(carSocket, i));
				carT.start();
			}
			
			// initialize Controllers
			for (int i = 1; i <= numControllers; i++) {
				Socket controllerSocket = new Socket(address, port);
				Thread controllerT = new Thread(new ControllerClient(controllerSocket, i));
				controllerT.start();
			}

		} catch (Exception exc) {
			System.out.println(exc.getMessage());
			exc.printStackTrace();
		}
	}

	
	public String ClientInfo() {

		return "********************************************************"
				+ System.lineSeparator()
				+ "* This is porject 2 of course CS344_715 Client Side.   *"
				+ System.lineSeparator()
				+ "* Student is Yuqian Zhang                              *"
				+ System.lineSeparator()
				+ "********************************************************";

	}
}
