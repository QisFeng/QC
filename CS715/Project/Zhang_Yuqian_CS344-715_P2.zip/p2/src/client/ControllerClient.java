package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import common.Message;
import common.Message.Command;
import common.Message.Role;


public class ControllerClient implements Runnable{
	private int id;
	private Socket socket = null;
	
	public ControllerClient (Socket socket, int id){
		this.socket = socket;
		this.id = id;
		System.out.println("ControllerClient -" + id);
	}	
	
	public void run(){
		
		try{
			ObjectOutputStream dos = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream dis = new ObjectInputStream(socket.getInputStream());
			
			// client identity
			Message recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			Message sendMsg = new Message("ControllerClient -"+ id,Role.Controller);
			System.out.println("Send identity: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			while (Project2Client.numCarDone < Project2Client.numCars) {	
				//System.out.println("---------------------------------");
				//receiveRequest
				sendMsg = new Message("ControllerClient -"+ id,Role.Controller, Command.receiveRequest);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg);
				
				if (Project2Client.numCarDone == Project2Client.numCars){//if all car done break
					break;
				}
				//booking
				sendMsg = new Message("ControllerClient -"+ id,Role.Controller, Command.booking);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg);
				
				//givePermission
				sendMsg = new Message("ControllerClient -"+ id,Role.Controller, Command.givePermission);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg);
			}
			//exit
			sendMsg = new Message("ControllerClient -"+ id,Role.Controller, Command.quit);
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			sendMsg = new Message("ControllerClient -"+ id,Role.Controller, Command.EXIT);
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			socket.close();
			System.out.println("ControllerClient -" + id+" exits...");
			
			}catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			}
	}
}
