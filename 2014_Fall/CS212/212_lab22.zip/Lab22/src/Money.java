import java.io.Serializable;


public abstract class Money implements Serializable {

}
