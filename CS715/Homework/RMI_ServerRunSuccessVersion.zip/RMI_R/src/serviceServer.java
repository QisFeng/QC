import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Hashtable;

public class serviceServer implements commonInterface{
	
	
	ArrayList<Integer> billCodedb = new ArrayList<Integer>();
	Hashtable<Integer,expense> expenseTable=new Hashtable<Integer,expense>();
	public static int port;
	public static int internalPort;	
	public int gid = 0;
	public serviceServer(){
		super();
	}
	
	
	public static void main(String[] args){
		port=Integer.parseInt(args[0]);
		internalPort=Integer.parseInt(args[1]);
		  try {
	            String name = "server";
	            commonInterface s = new serviceServer();
	            commonInterface stub = (commonInterface) UnicastRemoteObject.exportObject(s, internalPort);
	            Registry registry = LocateRegistry.createRegistry(port);
	            registry.rebind(name, stub);
	            System.out.println("server bound");
	        } catch (Exception e) {
	            System.err.println("server exception:");
	            e.printStackTrace();
	        }
	}

	@Override
	public boolean submit_Expense(expense obj) throws RemoteException {
		System.out.println("submit_Expense() is called");
		if(isValid (obj.billingCode)){
			System.out.println("submitExpense Successfully.");
			expenseTable.put(obj.id,obj);
			return true;}
		else 
			System.out.println("Invalid Billing code, rejected!");
		return false;
	}
	
	private boolean isValid(int code) {
		System.out.println("isValid() is called");
		for(int i=0;i<billCodedb.size();i++){
			if(billCodedb.contains(code)){
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean add_Billing_code(int c) throws RemoteException {
		System.out.println("add_BillingCode() is called");//delete later
		if(billCodedb.contains(c))
			return false;
		else
			billCodedb.add(c);
		return true;
	}


	@Override
	public boolean invalidate_a_Billing_code(int c) throws RemoteException {
		System.out.println("invalidate_a_Billing_code() is called");
		if (billCodedb.contains(c)){
			billCodedb.remove(new Integer(c));
			return true;}
		return false;
	}


	
	@Override
	public ArrayList<expense> get_all_Expenses_for_a_Billing_code(int c) throws RemoteException {
		System.out.println("get_all_Expenses_for_a_Billing_code() is called");
		ArrayList<expense> expenseList=new ArrayList<expense>();
		for (Integer i : expenseTable.keySet()){
			expense e = expenseTable.get(i);
			if (e.billingCode == c)
				expenseList.add(e);
		}
		return expenseList;
	}


	@Override
	public boolean invalidate_Expense(ArrayList<Integer> eid) throws RemoteException {
		System.out.println("invalidate_Expense() is called");
		int check=0;
		for(int i=0;i<eid.size();i++){
			int id = eid.get(i).intValue();
			if(expenseTable.containsKey(id)){
				expenseTable.remove(id);
				check++;}
		}
		if (check!= 0)
			return true;
		else return false;
		
	}


	@Override
	public int close_Account(int code) throws RemoteException {
		
		System.out.println("closeAccount() is called");
		// get All  Expense
		int totalExpense=0;
		ArrayList<expense> listforRemove = get_all_Expenses_for_a_Billing_code(code);	
		if(listforRemove==null){
			System.out.println("No this billing code");
			return 0;
		}
		for(int i=0;i<listforRemove.size();i++){
			totalExpense+=listforRemove.get(0).expenseCharged;
			int id=listforRemove.get(0).id;
			expenseTable.remove(id);//remove //remove expense id
			listforRemove.remove(0);//remove the expense object
		}
		billCodedb.remove(code);//finally remove the billing code 
		return totalExpense;
	}


	@Override
	public int idGenerator() throws RemoteException {
		return ++gid;
		
	}
}
