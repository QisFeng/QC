import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ThreadA extends Thread{
	private int id;
 	private InputStream        is;
 	private OutputStream       os;
 	private ObjectOutputStream oos;


	public ThreadA(int id, InputStream is, OutputStream os, ObjectOutputStream oos){
		this.id = id;
		this.is= is;
		this.os = os;
		this.oos = oos;
	}
	
	public void run(){
		System.out.println( "Thread A starts execution..." );
	    
	    try {
	    	//create object Message
	    	Message m=new Message(50, id);
	    	System.out.println("Thread A - creates an object: " + m);
	    	
	        //send object to Thread B
	    	oos = new ObjectOutputStream( os );
	        oos.writeObject( m );
	        System.out.println("Thread A - sends this object to Thread B.");
	        
	        // receive primitive data from Thread C
	        System.out.println("Thread A - receives primitive data from Thread C : "+is.read());
	        
	
	    } // end TRY
	    catch ( Exception exc ) {
	          System.out.println
	                ( "Error ThreadA: " + exc );
	    } // end CATCH
	}
	
	
	
}