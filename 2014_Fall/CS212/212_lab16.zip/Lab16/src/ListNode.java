// ListNode.java

class ListNode
{
   String data;
   ListNode next;

   ListNode(String d)
   {
      data = d;
      next = null;
   }  // constructor
}  // class ListNode

