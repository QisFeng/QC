
class ListNode {
	public Widget data;
	public ListNode next;
	
	public ListNode(Widget d){
		this(d,null);
	}
	public ListNode(Widget d, ListNode n){
		data = d;
		next = n;
	}

}
