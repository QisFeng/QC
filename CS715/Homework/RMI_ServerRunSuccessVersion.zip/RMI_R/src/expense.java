import java.io.Serializable;

public class expense implements  Serializable {
	int id;
	int billingCode;
	int employeeId;
	int expenseCharged;
	String expenseDescription;
	
	
	public expense(int id,int bc,int eid,int charged,String descp){
		this.id = id;
		this.billingCode=bc;
		this.employeeId= eid;
		this.expenseCharged= charged;
		this.expenseDescription= descp;
		
	}
	
	public String toString(){
		return "expense_"+id+" billingCode: "+billingCode+" employeeId: "+employeeId+" expensedCharged: "
					+expenseCharged+" expenseDescription:"+expenseDescription;
	}
	
	
}
