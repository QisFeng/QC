import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 * Requirement: 
 * 
   1.TA sends objects to TB.
   2.TB sends objects to TC.
   3.TC sends primitive data to TA and to TB
   
 * @author Yuqian Zhang
 *
 */
public class ConnectionManager {

	/**
	 * pipe for object data (TA->TB)
	 */
	static private PipedInputStream pis1;
	static private PipedOutputStream pos1;

	/**
	 * pipe for object data (TB->TC)
	 */
	static private PipedInputStream pis2;
	static private PipedOutputStream pos2;

	/**
	 * pipe for primitive data (TC->TA)
	 */
	static private PipedInputStream pis3;
	static private PipedOutputStream pos3;

	/**
	 * pipe for primitive data (TC->TB)
	 */
	static private PipedInputStream pis4;
	static private PipedOutputStream pos4;

	static private ObjectOutputStream oos;
	static private ObjectInputStream  ois;	
	
	public static void main(String argv[]) {
		try {

			// set up a pipe
			System.out.println("Pipe setup");
			pos1 = new PipedOutputStream();
			pis1 = new PipedInputStream(pos1);

			pos2 = new PipedOutputStream();
			pis2 = new PipedInputStream(pos2);

			pos3 = new PipedOutputStream();
			pis3 = new PipedInputStream(pos3);

			pos4 = new PipedOutputStream();
			pis4 = new PipedInputStream(pos4);

			System.out.println("Object creation");
			ThreadA tA = new ThreadA(1,pis3,pos1, oos);
			ThreadB tB = new ThreadB(2,pis4,pis1,pos2,oos,ois);
			ThreadC tC = new ThreadC(3,pis2,pos3,pos4,ois);
			
			System.out.println("Thread execution");
			tA.start();
			tB.start();
			tC.start();
			
		} // end TRY
		catch (Exception exc) {
			System.out.println(exc);
		} // end CATCH
	}
} // end CLASS ConnectionManager

