package server;

import java.util.Random;
/**
 * @author Yuqian Zhang
 * CS344-715  Project1
 * */

public class Project1 {
	
	public static int numPassengers;//numPassengers 23
	public static int numCars;//numCars 3
	public static int numControllers;//numControllers 2
	public static int numSeats;//numSeats 5
	
	public static long time = System.currentTimeMillis();;
	public static final int  MAXWAITTIME =1000;
	public static Random rand = new Random();;
	
	
	public static boolean all_took_ride = false;
	public static int numCarDone = 0;
	static MonitorPC pc = null;

	
	
	public static void main(String[] args) {
		
		numPassengers = Integer.parseInt(args[0]);
		numCars = Integer.parseInt(args[1]);
		numControllers = Integer.parseInt(args[2]);
		numSeats = Integer.parseInt(args[3]);
		
		pc = new MonitorPC();//make monitor available
		
		 //start Passenger thread
		for(int id =1;id<=numPassengers ;id++){
			new Passenger(id).start();
			//Passenger p = new Passenger(id);
			//passengers.put(p.getName(), p);
		}
		 //start Car thread
		for (int id = 1; id <= numCars; id++){ 
			new Car(id).start();
		 }
		 
		 //start Controller thread
		for(int id =1; id<= numControllers;id++){
			new Controller(id).start();
		}	
	}// main method
	
	public static void init(int p,int c,int cl,int s) {
		System.out.println("Initializing objects......");
		numPassengers = p;
		numCars = c;
		numControllers = cl;
		numSeats = s;
		
		pc = new MonitorPC();//make monitor available
		System.out.println("Setting up done");
		
/*		for(int id =1;id<=numPassengers ;id++){//initialize passengers hash map
			Passenger p = new Passenger(id);
			passengers.put(p.getName(), p);
		}
		
		for (int id = 1; id <= numCars; id++){ //initialize car hash map
			Car c = new Car(id);
			cars.put(c.getName(), c);
		 }
		 
		for(int id =1; id<= numControllers;id++){//initialize controller hash map
			Controller cl = new Controller(id);
			controllers.put(cl.getName(), cl);
		}	*/
	}

	
}
