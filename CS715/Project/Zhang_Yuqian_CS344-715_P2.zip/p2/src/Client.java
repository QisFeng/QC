import client.Project2Client;

//Please first start the Server class

public class Client {
	
	//Server port
	private static int port = 8803;
	
	//Server name/IP address
	private static String address = "localhost";

	public static void main(String args[]) {
		
		Project2Client client = new Project2Client(address, port);
		System.out.println(client.ClientInfo());
		client.start();
	}

	
}
