import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface commonInterface extends Remote {

	boolean submit_Expense(expense obj) throws RemoteException;

	boolean add_Billing_code(int c) throws RemoteException;

	boolean invalidate_a_Billing_code(int c) throws RemoteException;

	ArrayList<expense> get_all_Expenses_for_a_Billing_code(int c) throws RemoteException;

	boolean invalidate_Expense(ArrayList<Integer> eid) throws RemoteException;

	int close_Account(int code) throws RemoteException;

	int idGenerator() throws RemoteException;

}
