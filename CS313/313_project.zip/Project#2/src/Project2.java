



public class Project2 {
	
	
	static Inventory Inventorylist = new Inventory();
	static BackOrder BackOrderlist = new BackOrder();
	
	public static void main(String[] args) throws Exception{
		
		fillin("transactions.txt");
		
		
	}
	
	
	public static void fillin(String myFile) throws Exception {
		TextFileInput in = new TextFileInput(myFile); 
		String line = in.readLine();
		while(line!=null){
				
				Widget temp = new Widget (line);
				if(temp.getType().equals( "R"))
					Inventorylist.add(temp);
				if(temp.getType().equals( "S"))
					Inventorylist.calculate(temp);
			
			line = in.readLine();
		}
	}
	
	
	
}//end main
