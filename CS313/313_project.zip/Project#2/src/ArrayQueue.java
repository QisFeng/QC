
public class ArrayQueue {
	
	private int[] theArray;
	private int currentsize;
	private int front;
	private int back;
	private static int cap =10;
	
	public ArrayQueue(){
		theArray =  new int [cap];
		makeEmpty();
	}
	public boolean isEmpty(){
		return currentsize==0;
	}
	public void makeEmpty(){
		currentsize = 0;
		front = 0;
		back = -1;
	}
	public int deQ() throws Exception{
		if(isEmpty())
			throw new Exception("ArrayQueue dequeue");
		currentsize--;
		int temp = theArray[front];
		front = increment(front);
		return temp;
	}
	public int getFront() throws Exception{
		if(isEmpty())
			throw new Exception("ArrayQueue getFront");
		return theArray[front];
	}
	public void enQ(int x){
		if (currentsize==theArray.length)
			doubleQueue();
		back = increment(back);
		theArray[back] =x;
		currentsize++;
	}
	private int increment(int x){
		if(++x==theArray.length)
			x=0;
		return x;
	}
	private void doubleQueue(){
		int [] newArray;
		newArray = new int [theArray.length*2];
		for(int i=0;i<currentsize;i++,front=increment(front))
			newArray[i] = theArray[front];
		theArray = newArray;
		front = 0;
		back = currentsize -1;
	}
}
