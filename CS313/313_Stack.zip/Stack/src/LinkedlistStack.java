
public class LinkedlistStack {
	private ListNode top=null;
	
	public boolean isEmpty(){
		return top==null;
	}
	public void makeEmpty(){
		top=null;
	}
	public void Push(int x){
		top = new ListNode(x,top);
	}
	public void Pop() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		top = top.next;
	}
	public int Top() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		return top.data;
	}
	public int TopandPop() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		int topItem = top.data;
		top = top.next;
		return topItem;
	}
	
}
