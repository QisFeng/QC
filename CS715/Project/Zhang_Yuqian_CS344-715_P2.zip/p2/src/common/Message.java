package common;

import java.io.Serializable;

	  
public class Message implements Serializable {
		//Used to exchange message between clients and server
		private static final long serialVersionUID = 3635384963538773512L;

		public enum Command {
			wander,
			getOn,
			getOff,
			load,
			getPermission,
			rideAround,
			unload,
			finish,
			receiveRequest,
			booking,
			givePermission,
			quit,
			config_numPassengers,
			config_numCars,
			config_numControllers,
			config_numSeats,
			next,
			EXIT
		}

		public enum Role {
			Passenger,
			Car,
			Controller,
			Service,
			Other
		}

		public enum Type {
			text,
			command
		}

		
		//Identify the message owner		 
		private String sender;	
		private Role role;
		private String txtMsg;
		private int intValue;
		private Command cmd;
		private Type type = Type.text;

		
		public Message(String sender, Role role) {
			this.sender = sender;
			this.role = role;
		}

		
		public Message(String sender, Role role, String txtMsg) {
			this.sender = sender;
			this.role = role;
			this.txtMsg = txtMsg;
			type = Type.text;
		}

	
		public Message(String sender, Role role, Command command) {
			this.sender = sender;
			this.role = role;
			this.cmd = command;
			type = Type.command;
		}

		
		public Message(String sender, Role role, Command command, String txtMsg) {
			this.sender = sender;
			this.role = role;
			this.txtMsg = txtMsg;
			this.cmd = command;
			type = Type.command;
		}

		
		public Message(String sender, Role role, Command command, int intMsg) {
			this.sender = sender;
			this.role = role;
			this.intValue = intMsg;
			this.cmd = command;
			type = Type.command;
		}

		public String getSender() {
			return sender;
		}

		public void setOwner(String sender) {
			this.sender = sender;
		}

		public String getTxtMsg() {
			return txtMsg;
		}

		public void setTxtMsg(String txtMsg) {
			this.txtMsg = txtMsg;
		}

		public Type getType() {
			return type;
		}

		public void setType(Type type) {
			this.type = type;
		}

		public Command getCommad() {
			return cmd;
		}

		public void setCommand(Command cmd) {
			this.cmd = cmd;
		}

		public int getIntValue() {
			return intValue;
		}

		public void setIntValue(int intValue) {
			this.intValue = intValue;
		}

		public Role getRole() {
			return role;
		}

		public void setRole(Role role) {
			this.role = role;
		}

		/*@Override/*
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Message other = (Message) obj;
			if (cmd != other.cmd)
				return false;
			if (intValue != other.intValue)
				return false;
			if (role != other.role)
				return false;
			if (sender == null) {
				if (other.sender != null)
					return false;
			} else if (!sender.equals(other.sender))
				return false;
			if (txtMsg == null) {
				if (other.txtMsg != null)
					return false;
			} else if (!txtMsg.equals(other.txtMsg))
				return false;
			if (type != other.type)
				return false;
			return true;
		}*/

		@Override
		public String toString() {
			return "Message [sender=" + sender + ", role=" + role + ", txtMsg="
					+ txtMsg + ", intValue=" + intValue + ", cmd=" + cmd
					+ ", type=" + type + "]";
		}

}
