
public class Nickel extends Coin {

      public Nickel () {
         super (5);
      }
}
