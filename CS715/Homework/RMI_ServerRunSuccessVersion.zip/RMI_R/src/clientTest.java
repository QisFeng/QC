import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Random;


public class clientTest {
	static commonInterface server;
	public static int port=0;
	public static String name1="";
	public static void main(String args[]){
		name1=args[0];
		port=Integer.parseInt(args[1]);
		try{
			String name = "server";
            Registry registry = LocateRegistry.getRegistry(name1,port);//"localhost", 3000);
            server = (commonInterface) registry.lookup(name);
            
            //positive test starts here
            
            //---------add a new billing code---------Here for test add 5 billing code
            System.out.println("---------Positive Tests---------");
            for(int i=1;i<=5;i++){
            	boolean create;
            	create = server.add_Billing_code(i);
            	if (create)
            		System.out.println("A new billing Code:"+i+" added successfully.");	
            	else 
            		System.out.println("A new billing Code:"+i+" failed to add.");
            }
            
            //---------submit a new expense---------Here just for test add 3 expenses 
            
            expense obj1 = new expense(server.idGenerator(),1,1,555,"charged for extra time.");
            boolean ae1;
            ae1 = server.submit_Expense(obj1);
            if (ae1)
            	System.out.println("Submit Expense into billingCode 1"+"successfully.");	
        	else 
        		System.out.println("Submit Expense into billingCode 1"+"failed.");
            
            expense obj2 = new expense(server.idGenerator(),3,9,98,"charged for additional asset.");
            boolean ae2;
            ae2 = server.submit_Expense(obj2);
            if (ae2)
            	System.out.println("Submit Expense into billingCode 3"+"successfully.");	
        	else 
        		System.out.println("Submit Expense into billingCode 3"+"failed.");
            
            expense obj3 = new expense(server.idGenerator(),5,23,200,"charged for additional asset.");
            boolean ae3;
            ae3 = server.submit_Expense(obj3);
            if (ae3)
            	System.out.println("Submit Expense into billingCode 5"+" successfully.");	
        	else 
        		System.out.println("Submit Expense into billingCode 5"+" failed.");
            
            
            //---------test invalidate_a_Billing_code method---------invalid billing code 1
            boolean validB;
            validB = server.invalidate_a_Billing_code(1);
            if (validB)
            	System.out.println("Invalidate a billing code_1"+" successfully.");	
        	else 
        		System.out.println("Invalidate a billing code_1"+" failed.");            
            
            
 			//---------get_all_Expenses_for_a_Billing_code---------
             System.out.println("Get all Expenses for billing code:3");
             ArrayList<expense> list=server.get_all_Expenses_for_a_Billing_code(3);
             if(list!=null){
            	 for(int i=0;i<list.size();i++){
            		 System.out.println(i+""+list.get(i));
            	 }
             }
             else 
            	 System.out.println("No expenses for this billing code");
             
                           
             //---------invalidate_Expense---------
             //invalidate expense id:1,2
             ArrayList <Integer> a = new ArrayList <Integer>() ;
             a.add(1);
             a.add(2);
             boolean ve;
             ve = server.invalidate_Expense(a);
             if (ve)
            	 System.out.println("invalication expense id:1&2 success.");
             else 
            	 System.out.println("invalidation expense id:1&2 failed.");
             
             
             
             //---------close_Account---------
             //close account for billing code:2
             int totalnumber = server.close_Account(2);
             System.out.println("close accout for billingCode 2 "+"Total needs to pay:"+ totalnumber);
             
//-------------------------------------------------------------------------------------------------------           
             //negative test starts here
             System.out.println("---------Negative Tests---------");
             //---------remove a billing code 5 and use the old one to submit a expense---------
             boolean valid;
             valid = server.invalidate_a_Billing_code(5);
             if (valid)
             	System.out.println("Invalidate a billing code 5"+" successfully.");	
         	 else 
         		System.out.println("Invalidate a billing code 5"+" failed.");  
             
             expense obj4 = new expense(server.idGenerator(),5,9,98,"charged for additional asset.");
             boolean ae4;
             ae4 = server.submit_Expense(obj4);
             if (ae4)
             	System.out.println("Submit Expense into billingCode 5"+" successfully.");	
         	 else 
         		System.out.println("Submit Expense into billingCode 5"+" failed.");

             
             //---------invalidate group of expense---------
             ArrayList <Integer> b = new ArrayList <Integer>();
             b.add(1);
             b.add(2);
             boolean vg;
             vg = server.invalidate_Expense(b);
             if (vg)
            	 System.out.println("invalication expense success.");
             else 
            	 System.out.println("invalidation expense failed.");
             
             //---------get All Expenses---------
             System.out.println("Get all Expenses for billing code:1");
             ArrayList<expense> l=server.get_all_Expenses_for_a_Billing_code(1);
             for(int i=0;i<l.size();i++)
            	 System.out.println(i+""+l.get(i));
             if (l.size()==0)
            	 System.out.println("There is no expense for this billing code");
             
             
             //---------simulating the audit process---------
             simulatingAudit(3);

             
         } catch (Exception e) {
             System.err.println("Client exception:");
             e.printStackTrace();
         }
         
     }   

 	private static void simulatingAudit(int bcode) throws RemoteException {
 		 System.out.println("---------Simulating the audit process---------");
         //client download all expenses
         ArrayList<expense> list=server.get_all_Expenses_for_a_Billing_code(bcode);
         //if(list==null){System.out.println("not exist this the database");return;}
         System.out.println("Get all Expenses returned for billingcode"+bcode);
         for(int i=0;i<list.size();i++){
         	System.out.println(i+""+list.get(i));
         }
         //randomly choose EmployeeName to offending person
         Random rand=new Random();
         ArrayList<Integer> rm=new ArrayList<Integer>();
            if (list.size()==0){
            	System.out.println("There is no data exist this the database");
            	System.exit(0);}
     		int index=rand.nextInt(list.size());
     		int eid=list.get(index).employeeId;
     		
     		
 	    	for(int i=0;i<list.size();i++){
 	    		if(list.get(i).employeeId==eid)
 	    			rm.add(new Integer(list.get(i).id));
 	    	}
     		
     		//client submit request to remove all offending expenses
     		
     		boolean isTrue=server.invalidate_Expense(rm);	
     		if (isTrue)
           	 System.out.println("invalication expense success.");
            else 
           	 System.out.println("invalidation expense failed.");
               		
             //close account
             int n=server.close_Account(bcode);
             System.out.println("close accout for billingCode"+bcode+"Total needs to pay:"+ n);
 	}
}

 	

 	


 	
 		
 	
 
