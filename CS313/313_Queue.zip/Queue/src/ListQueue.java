
public class ListQueue {
	
	private ListNode front;
	private ListNode back;
	
	public ListQueue(){
		front = back = null;
	}
	public boolean isEmpty(){
		return front==null;
	}
	public void enQ(int x){
		if(isEmpty())
			back = front = new ListNode(x);
		else back = back.next = new ListNode(x);
	}
	public int deQ() throws Exception{
		if(isEmpty())
			throw new Exception("ListQueue dequeue");
		int temp = front.data;
		front= front.next;
		return temp;
		
	} 
	public int getFont() throws Exception{
		if(isEmpty())
			throw new Exception("ListQueue getFront");
		return front.data;
	}
	public void makeEmpty(){
		front = null;
		back = null;
	}
}
