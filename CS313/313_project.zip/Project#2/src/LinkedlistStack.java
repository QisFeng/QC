
public class LinkedlistStack {
	
	ListNode top=null;
	
	public boolean isEmpty(){
		return top==null;
	}
	public void makeEmpty(){
		top=null;
	}
	public void Push(Widget x){
		top = new ListNode(x,top);
	}
	public void Pop() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		top = top.next;
	}
	public Widget Top() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		return top.data;
	}
	public Widget TopandPop() throws Exception{
		if(isEmpty())
			throw new Exception("ListStack pop");
		Widget topItem = top.data;
		top = top.next;
		return topItem;
	}
	
}
