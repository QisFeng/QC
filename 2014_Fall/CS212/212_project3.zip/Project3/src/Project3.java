/**
 * @author Yuqian Zhang Section 11D
 *
 */
public class Project3 {
	
	static DateGUI myGUI;

	/**
	 * calling myGUI
	 */
	public static void main(String[] args){

		
		myGUI =new DateGUI();
		

	}

	
	



}


