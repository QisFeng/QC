
class ListNode {
	public int data;
	public ListNode next;
	
	public ListNode(int d){
		this(d,null);
	}
	public ListNode(int d, ListNode n){
		data = d;
		next = n;
	}

}
