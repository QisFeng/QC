
public class MoneyNode {
	   Money data;
	   MoneyNode next;

	   MoneyNode(Money d)
	   {
	      data = d;
	      next = null;
	   }  
}
