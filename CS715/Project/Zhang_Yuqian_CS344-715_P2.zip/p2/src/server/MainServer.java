package server;


import java.net.ServerSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainServer {
	
	private ServerSocket server;//server socket
	private int port;//server port
	public static int numPassengers;
	public static int numCars;
	public static int numControllers;
	public static int numSeats;
	
	public MainServer(int port,int p,int c,int cl,int s) {
		this.port = port;//Construct with port
		numPassengers=p;
		numCars=c;
		numControllers=cl;
		numSeats=s;
	}
	
	public void start() {
		try {
			// initialize environment
			Project1.init(numPassengers,numCars,numControllers,numSeats);
			server = new ServerSocket(port);
			while (true) {
				Socket connection = server.accept();
				// using thread to keep client and server conversion.
				SubServerThread service = new SubServerThread(connection);
				service.start();
			}
		} catch (Exception e) {
			System.out.println("Unable to listen to port.");
			e.printStackTrace();
		}
		serverInfo();
	}

	public String serverInfo() {
		InetAddress myAddress;
		try {
			myAddress = InetAddress.getLocalHost();

			return "********************************************************"
					+ System.lineSeparator()
					+ "* This is porject 2 of CS344_715.   Server Side        *"
					+ System.lineSeparator()
					+ "* Student Name : Yuqian Zhang                          *"
					+ System.lineSeparator()
					+ "********************************************************"
					+ System.lineSeparator() + "Access method from client:"
					+ System.lineSeparator() + "\tjava Client -host "
					+ myAddress.getHostAddress() + " -port " + port
					+ System.lineSeparator();

		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return null;
		}	
	}
	
}//class
