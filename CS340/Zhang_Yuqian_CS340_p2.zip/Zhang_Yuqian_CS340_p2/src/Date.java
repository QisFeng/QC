import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

public class Date extends Thread {

	public static ConcurrentLinkedQueue<Date> available = new ConcurrentLinkedQueue<>(); //current available dateQueue																					 
	Contestant chatting; // The contestant this date is currently chatting with
	Semaphore startTalk = new Semaphore(0);// use to check and call availabe date to make decision
	Semaphore answerReady = new Semaphore(0);//use to check if date gave her answer or not

	public Date(int i) {
		super("Date #" + i);
	}

	public void run() {
		talktoContestant();
	}

	// The date meets contestants until the show ends.
	private void talktoContestant() {
		available.add(this); // Set self as available
		while (true) {
			try {
				startTalk.acquire();//wait for being approached
				if (Project2.show_ends) { // Go home if the show has ended
					msg("Leaving.");
					return;
				}
				// -----set priority to make a decision-----
				setPriority(getPriority() + 1);
				msg("Feel rushed to make a decision.");
				if (Project2.rand.nextBoolean()) { // random decide give or not
					msg("Accept " + chatting.getName()+" and give her number.");
					chatting.phoneNumbers.add(getName());//  update current chatting CT's phoneNumber Array
				} else{
					msg("Reject " + chatting.getName() + " no number provided.");}
				setPriority(getPriority() - 1);
				// -----set back priority and continue-----
				answerReady.release();// give her answer 
				chatting = null;//clear current chatting CT for next one
				msg("Available again.");
				available.add(this);// adding back to the available queue
				SharedVariable.countingdate.release();//give out 1 available date
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void startTalk(Contestant chatting) {
		this.chatting = chatting;
		startTalk.release();
	}

	public void answer() {
		try {
			answerReady.acquire();//check if answer available
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void endShow() {
		startTalk.release();
	}

	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project2.time) + "]" + getName() + ": " + m);
	}// msg

}// Date
