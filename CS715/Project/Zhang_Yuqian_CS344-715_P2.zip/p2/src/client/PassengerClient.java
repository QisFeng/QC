package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import common.Message;
import common.Message.Command;
import common.Message.Role;

public class PassengerClient implements Runnable{
	private int id;
	private Socket socket = null;
	
	public PassengerClient (Socket socket, int id){
		this.socket = socket;
		this.id = id;
		System.out.println("PassengerClient -" + id);
	}
	
	public void run(){
		
		try{
			ObjectOutputStream dos = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream dis = new ObjectInputStream(socket.getInputStream());
					
			// client identity
			Message recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			Message sendMsg = new Message("PassengerClient -"+ id,Role.Passenger);
			System.out.println("Send identity: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			//wander
			sendMsg = new Message("PassengerClient -"+ id,Role.Passenger, Command.wander);
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			//getOn
			sendMsg = new Message("PassengerClient -"+ id,Role.Passenger, Command.getOn);
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg+"get on the car:"+recMsg.getTxtMsg());
			
			//getOff
			sendMsg = new Message("PassengerClient -"+ id,Role.Passenger, Command.getOff);
			sendMsg.setTxtMsg(recMsg.getTxtMsg());
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			sendMsg = new Message("PassengerClient -"+ id,Role.Passenger, Command.EXIT);
			System.out.println("Send: " + sendMsg);
			dos.writeObject(sendMsg);
			socket.close();
			System.out.println("PassengerClient -" + id +" exits...");

			}catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			}
	}
}
