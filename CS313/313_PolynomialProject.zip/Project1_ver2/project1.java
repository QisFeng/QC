/*CS313 Project 1 part (1) - Yuqian Zhang - Method 2
 * In this method :
 * Advantage: 
 * In the situation of x^100, do not need to input 100 times, save time.
 * The difference in the length of two polynomial will not result in IndexOutofBound Exception
 * Shortage: 
 * Inputing the data in every single polynomial is not as convenient as in array
 */
public class project1 {

	public static void main(String[] args) { 
		//setup polynomial p
        polynomial p1   = new polynomial(9, 3);
        polynomial p2   = new polynomial(3, 2);
        polynomial p3   = new polynomial(2, 1);
        polynomial p4   = new polynomial(5, 0);
        polynomial p    = p1.plus(p2).plus(p3).plus(p4);   // 9x^3 + 3x^2 + 2x + 5
        
        //setup polynomial q
        polynomial q1   = new polynomial(5, 3);
        polynomial q2   = new polynomial(1, 0);
        polynomial q    = q1.plus(q2);                     // 5x^3 + 1
        
        //print out the result
        System.out.println("p(x) =        " + p);
        System.out.println("q(x) =        " + q);
        System.out.println("p(x) + q(x) = " + p.plus(q));
        System.out.println("p(x) - q(x) = " + p.minus(q));
        System.out.println("p(x) * q(x) = " + p.times(q));
        System.out.println("p(3)        = " + p.evaluate(3));
        System.out.println("q(3)        = " + q.evaluate(3));
        System.out.println("p(3) + q(3) = " + p.plus(q).evaluate(3));
        System.out.println("p(3) - q(3) = " + p.minus(q).evaluate(3));
        System.out.println("p(3) * q(3) = " + p.times(q).evaluate(3)); 
   }
	
}
