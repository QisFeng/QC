
public abstract class Money {

}
