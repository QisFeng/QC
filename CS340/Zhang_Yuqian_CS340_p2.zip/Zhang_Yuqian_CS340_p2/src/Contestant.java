import java.util.*;

public class Contestant extends Thread {

	int id;
	ArrayList<Date> attemptedDate = new ArrayList<>(Project2.num_rounds); 
	ArrayList<String> phoneNumbers = new ArrayList<>(Project2.num_rounds); 
	static int count = 0;//count to check if reach num_Contestant
	static int num = 0;//count to check if a group is united

	public Contestant(int i) {// set id for each contestant
		super("Contestant_" + i);
		id = i;
	}

	public void run() {
		goforSmartPant();
		goforDate();
		patonSP();
		braggingExit_in_Group();
	}

	// The contestants go for SmartPants and enters the club.
	private void goforSmartPant() {
		randomWait(5); // Arrive at a random time
		msg("Arrived at SmartPant and waiting to talk.");
		try {
			SharedVariable.mutexTalkNum.acquire();//Protected by mutual exclusive 
			SharedVariable.talkedNum++;//increase talkedNum in sharedVariable 
			if (SharedVariable.talkedNum == Project2.num_Contestant) {
				SharedVariable.waitforCT.release();//tell SP all CTs arrived
			}
			SharedVariable.mutexTalkNum.release();//Protected by mutual exclusive
			SharedVariable.talkedtoSP.acquire();//talk to SP
			msg("Talked to SmartPant and get passed! Entering the club now.");// Enter the club	
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// The contestants go to date with num_rounds attemptions to get phone numbers
	private void goforDate() {
		while (attemptedDate.size() < Project2.num_rounds) {// Limit each contestant's attemption to num_rounds
			Date date = getAvailableDate(); // get available date
			attemptedDate.add(date); // update attemptedDate array size
			msg("Chatting with " + date.getName() +" and ask for her number. Attemption: " + attemptedDate.size());
			randomWait(3); // small talk
			date.startTalk(this);// pass self for date to make a decision
			date.answer(); // Wait until get result from date and move on to next attemption
		}
	}

	// get available date
	private Date getAvailableDate() {
		try {
			SharedVariable.countingdate.acquire();//block until there is available dates
			return Date.available.remove();//pop & remove the date
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	// The contestant tells SmartPant whose phone numbers he got and gets a pat
	// on the back.
	private void patonSP() {
		randomWait(5); // Go to SmartPants
		try {
			SharedVariable.mutexPatSP.acquire();//Protect Mutual Exclusive
			Project2.contestant_done++;// Increment the number of contestants_done 
			SmartPant.SayingCongtowho = this;//set Current talking CT
			msg("Yeah!~~I've done. Here is phone numbers I got: "+ phoneNumbers.toString());
			SharedVariable.sayingCongto.release();//notify SP to say congratulation
			SharedVariable.congratulatedready.acquire();//reveived Congratulations
			SharedVariable.mutexPatSP.release();//Protect Mutual Exclusive
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// When job done bragging outside, once unite a group_size, a group exits
	private void braggingExit_in_Group() {
		try {
			randomWait(3); // Bragging
			SharedVariable.mutexgroup.acquire();//protect Mutual Exclusive
			count++;
			num++;
			//
			if (num < Project2.group_size && count != Project2.num_Contestant) {
				SharedVariable.mutexgroup.release();//protect Mutual Exclusive
				SharedVariable.groupready.acquire();//waiting to unite a group
				msg("left...");
			} else {
				msg("Group is ready, let's go home!");
				SharedVariable.groupready.release(num-1);
				msg("left...");
				num = 0;
				SharedVariable.mutexgroup.release();//protect Mutual Exclusive
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void randomWait(int num) {
		try {
			sleep(Project2.rand.nextInt(Project2.MAXWAITTIME * num));
		} catch (InterruptedException e) {
		}
	}// random sleep

	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project2.time) + "]" + getName() + ": " + m);
	}// msg

}// Contestant
