import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;

public class ThreadC extends Thread{
	private int id;
	private InputStream        is;
	private OutputStream	   ostoA;
 	private OutputStream       ostoB;
 	private ObjectInputStream ois;

 	
 	public ThreadC(int id,InputStream is, OutputStream ostoA, OutputStream ostoB, ObjectInputStream ois){
 		this.id = id;
 		this.is = is;
 		this.ostoA = ostoA;
 		this.ostoB = ostoB;
 		this.ois = ois;
 	}
 	
 	public void run(){
 		System.out.println("Thread C starts execution...");
 		try{
 			//received object from Thread B
 			ois = new ObjectInputStream(is);
 			Message m = (Message) ois.readObject();
			System.out.println("Thread C - receives an Object from Thread B : "+m);
 			
 			//write primitive data to Thread A
 			ostoA.write(70);
 			System.out.println("Thread C - sends primitive data(70) to Thread A");
 			
 			
 			//write primitive data to Thread B
 			ostoB.write(90);
 			System.out.println("Thread C - sends primitive data(90) to Thread B");
 			
 			
 			
 		}catch (Exception e) {
			System.out.println( "Error ThreadC: " + e);
		}
 		
 		
 		
 		
 	}
}
