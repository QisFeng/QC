
public class Polynomial {
	private int [] coef;//coefficients
	public int deg;		//degree of polynomial
	
	//constructor without given degree
	public Polynomial(){
		deg =0;
		coef = new int [deg];
	}
	
	//constructor with given degree
	public Polynomial(int[]a){
		deg = a.length-1;
		coef = new int [deg+1];
		for(int i=0;i<=deg;i++)
			coef[i]=a[i];
	}
	
	//addition,return c = a+b Time complexity is O(n).
	public Polynomial plus(Polynomial b){
		Polynomial a = this;
		Polynomial c = new Polynomial();
		c.deg=Math.max(a.deg,  b.deg);
		c.coef=new int [c.deg+1];
		for(int i =0;i<=c.deg;i++){
			c.coef[i] =a.coef[i]+b.coef[i];
		} 
		return c;
	}
	
	//subtraction,return c = a-b Time complexity is O(n)
	public Polynomial minus(Polynomial b){
		Polynomial a = this;
		Polynomial c = new Polynomial();
		c.deg=Math.max(a.deg,  b.deg);
		c.coef=new int [c.deg+1];
		for(int i =0;i<=c.deg;i++){
			c.coef[i] =a.coef[i]-b.coef[i];
		} 
		return c;
	}
	
	//multiply,return(a*b) Time complexity is O(n^2)
	public Polynomial times(Polynomial b){
		Polynomial a = this;
		Polynomial c = new Polynomial();
		c.deg=a.deg+b.deg;
		c.coef=new int [c.deg+1];
		for(int i =0;i<=a.deg;i++) 
			for(int j =0;j<=b.deg;j++) 
				c.coef[i+j]+=(a.coef[i]*b.coef[j]);
		return c;
	}
	
	//evaluate Time complexity is O(n)
	public int evaluate(int x) {
        int p = 0;
        for (int i = deg; i >= 0; i--)
            p = coef[i] + (x * p);
        return p;
    }
	
	//toString Time complexity is O(n)
	public String toString() {
        if (deg ==  0) return "" + coef[0];
        if (deg ==  1) return coef[1] + "x + " + coef[0];
        String s = coef[deg] + "x^" + deg;
        for (int i = deg-1; i >= 0; i--) {
            if      (coef[i] == 0) continue;
            else if (coef[i]  > 0) s = s + " + " + ( coef[i]);
            else if (coef[i]  < 0) s = s + " - " + (-coef[i]);
            if      (i == 1) s = s + "x";
            else if (i >  1) s = s + "x^" + i;
        }
        return s;
    }	
}
