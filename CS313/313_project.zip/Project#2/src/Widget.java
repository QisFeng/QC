import java.util.StringTokenizer;


public class  Widget {
	
	private String type;
	private int amount;
	private float price;
	public static StringTokenizer myTokens;
		
	/**
	 * Creating a Widget constructor to initialize the 
	 * value of type/amount/price
	 */
	public Widget(String d){
		myTokens = new StringTokenizer(d," ");
		
		type = myTokens.nextToken();
		amount = Integer.parseInt(myTokens.nextToken());
		if (myTokens.hasMoreTokens())
			price = Float.parseFloat(myTokens.nextToken());
			
	}
	
	public String getType(){
		return type;
	}
	public int getAmount(){
		return amount;
	}
	public float getPrice(){
		return price;
	}
	
	
}

