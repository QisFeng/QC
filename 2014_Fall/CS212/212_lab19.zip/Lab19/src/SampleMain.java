
public class SampleMain {
   static SampleGUI sampleGUI;
   public static void main(String[] args) {
      sampleGUI = new SampleGUI("My Sample GUI", 500,300);
   }
}
