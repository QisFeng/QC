import java.util.*;

public class Contestant extends Thread {

   int id;
   ArrayList<Date> attempted = new ArrayList<>(Project1.num_rounds); // The dates this contestant has attempted
   ArrayList<String> phoneNumbers = new ArrayList<>(Project1.num_rounds); // All phone numbers this contestant has gotten
   
   public Contestant(int i) {//set id for each contestant
      super("Contestant_" + i);
      id = i;
   }

   public void run() {
      goforSmartPant();
      goforDate();
      patonSP();
      bragging();
   }

   // The contestants go for SmartPants and enters the club.
   private void goforSmartPant() {
      randomWait(5); // Arrive at a random time
      msg("Arriving at SmartPant and waiting to talk.");
      SmartPant.spQ.add(this); // Add self to spQ to talk SmartPants
      while (!interrupted()); // Wait to be called by SmartPants once get permission
      msg("Entering the club now."); // Enter the club 
   }

   // The contestants go to date with num_rounds attemptions to get phone numbers
   private void goforDate() {
      while (attempted.size() < Project1.num_rounds) {
         Date date = getAvailableDate(); //get available date
         
         if (date == null){ // Go to the juice bar if no dates are available
            msg("Going to the juice bar.[No date available]");
            Thread.yield();
            randomWait(4);
         }
         else {
            attempted.add(date); // Remember the date already attempted
            date.chatting = this; // date is currently chatting with the current thread, make a connection
            msg("Chatting with " + date.getName() + " and ask for her number. (attempt #" + attempted.size() + ")");
            randomWait(3); // Briefly talk
            date.interrupt();// call date to make a decision
            while (!interrupted()); // Wait until get result from date and move on to next attemption
         }
      }//Limit each contestant's attemption to num_rounds 
   }
   
   //get available date 
   private Date getAvailableDate() {
      synchronized(Date.available) { // 2 contestants cannot attempt the same date in the mean time
         ArrayList<Date> currtAvailable = new ArrayList<Date>(Date.available);//copy the available list from current date.available
         currtAvailable.removeAll(attempted); // //Each contestant cannot attempt 1 date twice,so remove the ones already approached
         if (currtAvailable.isEmpty())
            return null;//no date is availabe
         else {
            Date date = currtAvailable.get(0);//get the first available date in the queue
            Date.available.remove(date); // set this date be unavailable since it is currently being chatting
            return date;// return this date 
         }
      }
   }

   // The contestant tells SmartPant whose phone numbers he got and gets a pat on the back.
   private void patonSP() {
      randomWait(1); // Go to SmartPants's table
      synchronized(Project1.smartpants) { // synchronized so that 2 contestants won't be at SmartPants's table at the same time
    	  msg("Patting on SmartPants, and" + " providing phone numbers he got: " + phoneNumbers.toString());
    	  Project1.contestant_done++;// Increment the number of contestants who have finished all rounds.
    	  SmartPant.SayingCongto = this; // Tell SmartPant who he's congratulating
    	  Project1.smartpants.interrupt();
    	  while (!interrupted()); // Wait to be congratulated before releasing the lock
      }
   }

   // The contestant bragginf, waits for the next contestant if they are still in the club, if not, go home.
   private void bragging() {
      randomWait(3); // Brag
      // If the next contestant is still in the club, wait and join.
      if (id != Project1.num_Contestant && Project1.contestants[id+1].isAlive())
         try {
            msg("Waiting to join " + Project1.contestants[id+1].getName());
            Project1.contestants[id+1].join();
         } catch (InterruptedException e) {}
      msg("Going home.");
   }

   private static void randomWait(int num) {
      try {
        sleep(Project1.rand.nextInt(Project1.MAXWAITTIME*num));
      } catch (InterruptedException e) {}
   }//random sleep

   private void msg(String m){ 
		System.out.println("["+(System.currentTimeMillis()-Project1.time)+"]"+getName()+": "+m);
	}//msg

}//Contestant
