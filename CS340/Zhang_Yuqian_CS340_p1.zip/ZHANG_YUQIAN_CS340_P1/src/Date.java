import java.util.concurrent.ConcurrentLinkedQueue;

public class Date extends Thread {

   public static ConcurrentLinkedQueue<Date> available = new ConcurrentLinkedQueue<>(); // All dates not currently talking to a contestant
   Contestant chatting; // The contestant this date is currently chatting with 
   
   
   public Date(int i) {
      super("Date #" + i);
   }

   public void run() {
      talktoContestant();
   }

   // The date meets contestants until the show ends.
   private void talktoContestant() {
      available.add(this); // Set self as available
      while (true) {
    	  while (!interrupted()) // Wait to be chat
			if (Project1.show_ends) { // Go home if the show has ended
			   msg("Leaving.");
			   return;}
			 //set priority to make a decision
			 setPriority(getPriority()+1);
			 msg("Feel rushed to make a decision.");
			 //if (Project1.rand.nextDouble() < .4)
			if (Project1.rand.nextBoolean()){ // random decide give or not
			msg("Accept " + chatting.getName() +" and give her number.");
			chatting.phoneNumbers.add(getName());//add this date's information to current chatting Contestant phoneNumber's record book
			 }
			 else
			    msg("Reject " + chatting.getName()+" no number provided.");
		 setPriority(getPriority()-1);
		 
		 chatting.interrupt();//tell the chatting contestant the result
		 msg("Decision made and now available again.");
		 available.add(this);//adding back to the available queue
		}
   }

   private void msg(String m){ 
		System.out.println("["+(System.currentTimeMillis()-Project1.time)+"]"+getName()+": "+m);
	}//msg
   
}//Date 
