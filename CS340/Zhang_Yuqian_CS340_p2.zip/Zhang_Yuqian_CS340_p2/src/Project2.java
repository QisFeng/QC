import java.util.*;

/**
 * @author Yuqian Zhang
 * @CS340 Project2
 * */

public class Project2 {
	
	public static int num_Contestant = 10;
	public static int num_date = 6;
	public static int num_rounds = 3;
	public static int group_size = 3;
	public static long time = System.currentTimeMillis();
	public static final int MAXWAITTIME = 1000;
	public static Random rand = new Random();
	public static SmartPant smartpants;
	public static Contestant[] contestants;   
	public static int contestant_done = 0;
	public volatile static boolean show_ends = false;
	
	
	
	public static void main(String[] args) {
	      
		num_Contestant = Integer.parseInt(args[0]);
		num_date = Integer.parseInt(args[1]);
		num_rounds = Integer.parseInt(args[2]);
		group_size = Integer.parseInt(args[3]);
		  
		//Start smartpant thread
		 (smartpants = new SmartPant("SmartPants")).start();
		 
		//make an array for all contestant
		 //start each Contestant thread 
		 contestants = new Contestant[num_Contestant+1];
		 for (int id = 1; id <= num_Contestant; id++){
			 (contestants[id] = new Contestant(id)).start();
		 }
		
		 //start each Date thread
		 for (int id = 1; id <= num_date; id++)
		     new Date(id).start();
		 
		
	}//main method
	
}//Project2 
