
public class Inventory {

	LinkedlistStack list = new LinkedlistStack();
	BackOrder BackOrderArr = new BackOrder();
	BackPrice PirceOrder = new BackPrice();
	int sum=0;
	
	public void add(Widget x) throws Exception{
		list.Push(x);
		sum+=x.getAmount();
		while (!BackOrderArr.isEmpty()){
			if (BackOrderArr.getFront()<=sum){
				Widget BO=new Widget("S"+" "+BackOrderArr.getFront());
				calculate2(BO);
			}else break;
		}
	}
	
	public void calculate(Widget x) throws Exception{
			if(x.getAmount()<=sum){
				bookkeeper(x.getAmount());
				sum-=x.getAmount();
				}
			else{
				BackOrderArr.enQ(x.getAmount());
				PirceOrder.enQ(list.Top().getPrice());
			} 
	}
	
	public void calculate2(Widget x) throws Exception{
				bookkeeper2(x.getAmount());
				sum-=x.getAmount();
				BackOrderArr.deQ();
				PirceOrder.deQ();
	}
	
	public void bookkeeper(int x) throws Exception{
		System.out.println("Actual cost:");
		float totalcost=0;
		while (x>0){
			if (x<=list.Top().getAmount()){
				System.out.println(x+" "+"@"+list.Top().getPrice()+"="+x*list.Top().getPrice());
				totalcost+=x*list.Top().getPrice();
				int NewAmount = list.Top().getAmount()-x;
				Widget NewPrice=new Widget("R"+ " "+NewAmount+" "+list.Top().getPrice());
				list.Pop();
				list.Push(NewPrice);
				x=0;
			}
			else{
			System.out.println(list.Top().getAmount()+" "+"@"+list.Top().getPrice()+"="+list.Top().getAmount()*list.Top().getPrice());
			totalcost+=x*list.Top().getPrice();
			x=x-list.TopandPop().getAmount();
			}
		}
		System.out.println("Total cost = "+totalcost);
		System.out.println("Customer's receipt = "+totalcost*1.4);
		System.out.println();
	}
	
	public void bookkeeper2(int x) throws Exception{
		System.out.println("Actual cost:");
		float totalcost=0;
		while (x>0){
			if (x<=list.Top().getAmount()){
				System.out.println(x+" "+"@"+list.Top().getPrice()+"="+x*list.Top().getPrice());
				totalcost+=x*list.Top().getPrice();
				int NewAmount = list.Top().getAmount()-x;
				Widget NewPrice=new Widget("R"+ " "+NewAmount+" "+list.Top().getPrice());
				list.Pop();
				list.Push(NewPrice);
				x=0;
			}
			else{
			System.out.println(list.Top().getAmount()+" "+"@"+list.Top().getPrice()+"="+list.Top().getAmount()*list.Top().getPrice());
			totalcost+=x*list.Top().getPrice();
			x=x-list.TopandPop().getAmount();
			}
		}
		System.out.println("Total cost = "+totalcost);
		System.out.println("Customer's receipt = "+BackOrderArr.getFront()*PirceOrder.getFront()*1.4);
		System.out.println();
	}
	
}
