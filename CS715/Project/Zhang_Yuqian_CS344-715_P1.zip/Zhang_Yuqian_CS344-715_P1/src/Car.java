
public class Car extends Thread{
	
	private int number;
	private int seatUsed = 0;
	
	public Car(int i){
		super ("Car#" + i);
		this.number = i;
	}
	
	public void run(){
		while(!Project1.all_took_ride){
			Project1.pc.load(this);
			msg("loaded.");
			
			if (Project1.all_took_ride && seatUsed ==0) {
				Project1.pc.carDone();
				break; // all done
			}
			
			Project1.pc.getPermission(this);
			msg("got persmission.");
			
			rideAround(4);
			
			Project1.pc.unload(this);
			msg("unload all passengers and availabe again.");
			}
	}
	
	public int getNubmer() {
		return this.number;
	}
	
	public synchronized void useSeat() {
		this.seatUsed++;
	}
	
	public synchronized void releaseSeat()  {
		this.seatUsed--;
	}
	
	public synchronized int getSeatUsed() {
		return this.seatUsed;
	}
	
	private void rideAround(int num) {
		try {
			sleep(Project1.rand.nextInt(Project1.MAXWAITTIME * num));
			msg("rides around the park.");
		} catch (InterruptedException e) {
		}
	}// wander method
	
	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project1.time) + "]" + getName() + ": " + m);
	}// msg
}
