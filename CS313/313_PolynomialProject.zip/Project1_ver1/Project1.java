/*CS313 Project 1 part (1) - Yuqian Zhang - Method 1
 * In this method :
 * Advantage: 
 * Input data is simple(input the array).
 * Shortage: 
 * if there is x^100, degree=100, I need to input 101 times, which cost time.
 * The length of two arrays(degrees of two polynomial) should be inputed as the same. Otherwise, it will
 	encounter ArrayindexOutofBound Exception in the calculation method.
 */
public class Project1 {
	
	public static void main(String args[]){
		//input two polynomial
		int p[]={5,2,3,9};
		int q[]={1,0,0,5};
		
		//transfer array to the type of polynomial
		Polynomial x = new Polynomial(p);
		Polynomial y = new Polynomial(q);
		
		//do the calculation and print out the result
		System.out.println("p(x) 	    = " + x);
        System.out.println("q(x)        = " + y);
		System.out.println("p(x) + q(x) = " + x.plus(y));
		System.out.println("p(x) - q(x) = " + x.minus(y));
		System.out.println("p(x) * q(x) = " + x.times(y));
		System.out.println("p(3)        = " + x.evaluate(3));
        System.out.println("q(3)        = " + y.evaluate(3));
        System.out.println("p(3) + q(3) = " + x.plus(y).evaluate(3));
        System.out.println("p(3) - q(3) = " + x.minus(y).evaluate(3));
        System.out.println("p(3) * q(3) = " + x.times(y).evaluate(3));
	}
	
}
