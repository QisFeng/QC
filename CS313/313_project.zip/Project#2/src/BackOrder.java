
public class BackOrder {
	
	ArrayQueue array = new ArrayQueue();
	
	public void enQ(int x){
		array.enQ(x);
	}
	public boolean isEmpty(){
		return array.isEmpty();
	}
	
	public int getFront() throws Exception{
		return array.getFront();
	} 
	public int deQ() throws Exception{
		return array.deQ();
	}
	
}
