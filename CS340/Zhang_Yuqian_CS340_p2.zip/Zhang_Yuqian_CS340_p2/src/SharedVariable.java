import java.util.concurrent.Semaphore;


public class SharedVariable {
	
	static int talkedNum = 0;//number of contestants talked to SmartPant to enter club
	
	static Semaphore waitforCT=new Semaphore(0);//use to check if all CT arrived at SP
	
	static Semaphore mutexTalkNum = new Semaphore(1);//protect ME when CT talk to SP
	
	static Semaphore talkedtoSP = new Semaphore(0);//use to check CT talked to SP
	
	static Semaphore countingdate = new Semaphore(Project2.num_date);//use to check available date
	
	static Semaphore mutexPatSP = new Semaphore(1);//Protect Mutual Exclusive when CT pat on SP
	
	static Semaphore sayingCongto = new Semaphore (0);//SP notify there's CT finished and say Congr
	
	static Semaphore congratulatedready = new Semaphore(0);//check if SP said Congratulations
	
	static Semaphore mutexgroup = new Semaphore(1);//protect ME when unite a group
	
	static Semaphore groupready = new Semaphore(0);//check if a group_size is united
	
	
	
	
	
}
