package server;

public class Passenger extends Thread{
	
	public Passenger(int i){
		super ("Passenger_"+i);
		
	}
	
	public Passenger(String name) {
		super(name);
	}
	
	public void run(){
		wander(5);//sleep random time 
		
		Car car = Project1.pc.getOn(this);// waits for car and get on
		
		Project1.pc.getOff(this, car);		
	}

	
	public void wander(int num) {
		try {
			sleep(Project1.rand.nextInt(Project1.MAXWAITTIME * num));
			msg("went around and line up to get car.");
		} catch (InterruptedException e) {
		}
	}// wander method
	
	
	private void msg(String m) {
		System.out.println("[" + (System.currentTimeMillis() - Project1.time) + "]" + getName() + ": " + m);
	}// msg method

}//Passenger Thread
