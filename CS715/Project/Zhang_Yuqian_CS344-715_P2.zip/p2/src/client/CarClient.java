package client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import common.Message;
import common.Message.Command;
import common.Message.Role;



public class CarClient implements Runnable{
	private int id;
	private Socket socket = null;
	
	private int carSeatUsed;
	
	public CarClient (Socket socket, int id){
		this.socket = socket;
		this.id = id;
		System.out.println("CarClient -" + id);
	}
	
	
	public void run(){
		
		try{
			ObjectOutputStream dos = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream dis = new ObjectInputStream(socket.getInputStream());
			
			// client identity
			Message recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			Message sendMsg = new Message("CarClient -"+ id,Role.Car);
			System.out.println("Send identity: " + sendMsg);
			dos.writeObject(sendMsg);
			recMsg = (Message) dis.readObject();
			System.out.println("The server responds: " + recMsg);
			
			while(!Project2Client.all_took_ride){
				//load
				sendMsg = new Message("CarClient -"+ id,Role.Car, Command.load);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg +"loaded.");
				
				//int carSeadUsed = Integer.parseInt(recMsg.getTxtMsg());
				carSeatUsed = recMsg.getIntValue();
				
				
				//getPermission
				sendMsg = new Message("CarClient -"+ id,Role.Car, Command.getPermission);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg+"got persmission.");
				
				//rideAround
				sendMsg = new Message("CarClient -"+ id,Role.Car, Command.rideAround);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				System.out.println("The server responds: " + recMsg);
				
				//unload
				sendMsg = new Message("CarClient -" + id,Role.Car, Command.unload,Project2Client.numPassengers);
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				recMsg = (Message) dis.readObject();
				
				System.out.println("The server responds: " + recMsg+"unload all passengers and availabe again.");
				Project2Client.all_took_ride = Boolean.parseBoolean(recMsg.getTxtMsg());
				Project2Client.numCarDone++;
							
				if (Project2Client.all_took_ride && carSeatUsed == 0) {
					//Exit
					sendMsg = new Message("CarClient -" + id,Role.Car, Command.EXIT);
					System.out.println("Send message: " + sendMsg);
					dos.writeObject(sendMsg);
					socket.close();
					System.out.println("CarClient -"+ id+ " exits...");
					//break; // all done
				}
				/*sendMsg = new Message("CarClient -" + id,Role.Car, recMsg.getCommad());
				System.out.println("Send: " + sendMsg);
				dos.writeObject(sendMsg);
				socket.close();
				System.out.println("CarClient -"+ id+ " finishes...");
				//System.out.println("The server responds: " + recMsg);*/
			}
			
			
			}catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			}		
	}
}
