public class BackPrice {
	
	PriceQueue array = new PriceQueue();
	
	public void enQ(float x){
		array.enQ(x);
	}
	public boolean isEmpty(){
		return array.isEmpty();
	}
	
	public float getFront() throws Exception{
		return array.getFront();
	} 
	public float deQ() throws Exception{
		return array.deQ();
	}
	
}
